Struktura adresáře:
apps - Spustitelný jar soubor s předpřipravenými daty (soubor anotated.csv musí být vždy s JAR soubourem !!)
doc - Dokumentace semestrální práce ve formátu PDF
javadoc - Vygenerovaná javadoc dokumentace k semestrální práci
src - Source soubory semestrální práce